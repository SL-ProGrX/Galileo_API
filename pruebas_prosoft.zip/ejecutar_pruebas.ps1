﻿# Ejecuta cada XML de esta carpeta contra el WCF y valida los campos esperados.
# Uso:  powershell -File .\ejecutar_pruebas.ps1 [-Url http://localhost:4176/CSG/CoreInternoServicio.svc]
param(
    [string]$Url = 'http://localhost:4176/CSG/CoreInternoServicio.svc',
    # El WCF inicia sesion en el API en cada llamada y el API permite 20 inicios por minuto.
    [double]$PausaSegundos = 3.3
)

$dir = $PSScriptRoot

# Validaciones por archivo: lista de { Campo (nombre local del elemento), Valor esperado (regex) }.
# 'FAULT' = la respuesta no debe ser un SOAP Fault.
$checks = [ordered]@{
    '01_ObtenerCuentaIBAN_ok.xml'                     = @(@('Resultado','^true$'), @('Estado','^1$'), @('DesProducto','\S'), @('Moneda','^1$'))
    '02_ObtenerCuentaIBAN_inexistente.xml'            = @(@('Resultado','^false$'), @('Estado','^28$'), @('NumError','^28$'))
    '03_ObtieneInfoCuenta_ok.xml'                     = @(@('Resultado','^Exitoso$'), @('Moneda','^1$'), @('MotivoError','^0$'))
    '04_ObtieneInfoCuenta_cedula_incorrecta.xml'      = @(@('Resultado','^Rechazo$'), @('MotivoError','^32$'))
    '05_ValidaCreditos_moneda_incorrecta.xml'         = @(@('Resultado','^Rechazo$'), @('MotivoError','^91$'))
    '06_ValidaCreditos_monto_negativo.xml'            = @(@('Resultado','^Rechazo$'), @('MotivoError','^96$'))
    '07_ValidaDebitos_cuenta_credito.xml'             = @(@('Resultado','^Rechazo$'), @('MotivoError','^93$'))
    '08_ValidaDebitos_monto_negativo.xml'             = @(@('Resultado','^Rechazo$'), @('MotivoError','^96$'))
    '09_ValidarPerfilTransaccional.xml'               = @(@('Resultado','^true$'), @('Estado','^1$'))
    '10_SaldoDisponible_moneda_incorrecta.xml'        = @(@('SaldoDisponibleResult','^Rechazo$'), @('disponible','^false$'))
    '11_ObtenerProductosPorCliente.xml'               = @(@('ObtenerProductosPorClienteResult','^Exitoso$'), @('Cuota','^(?!0(\.0+)?$)\d'), @('MovimientosPermitidos','^Acreditar$'), @('Saldo','^(?!0(\.0+)?$)\d'))
    '12_ObtenerCuentaIBAN_bloqueada.xml'              = @(@('Resultado','^true$'), @('Estado','^31$'))
    '13_ObtenerCuentaIBAN_cerrada.xml'                = @(@('Resultado','^true$'), @('Estado','^23$'))
    '14_ServicioDisponible.xml'                       = @(,@('ServicioDisponibleResult','^true$'))
    '15_ValidaCuenta_ok.xml'                          = @(@('Resultado','^Exitoso$'), @('MotivoError','^0$'))
    '16_ComisionRespectiva.xml'                       = @(,@('ComisionRespectivaResult','^Exitoso$'))
    '17_ObtenerTipoCambio.xml'                        = @(@('TipoCambioAplicado','^1(\.0+)?$'), @('montoTotal','^1000(\.0+)?$'))
    '18_ObtenerInformacionCliente.xml'                = @(,@('ObtenerInformacionClienteResult','^Exitoso$'))
    '19_SaldoDisponible_ok.xml'                       = @(@('SaldoDisponibleResult','^Exitoso$'), @('disponible','^true$'))
    '20_SaldoDisponible_moneda_no_disponible.xml'     = @(@('SaldoDisponibleResult','^Rechazo$'), @('disponible','^false$'))
    '21_ValidaCreditos_ok.xml'                        = @(@('Resultado','^Exitoso$'), @('MotivoError','^0$'))
    '22_ValidaDebitos_fondo_cuenta_valida.xml'        = @(@('Resultado','^Rechazo$'), @('MotivoError','^21$'))
    '23_ValidaDebitos_moneda_incorrecta.xml'          = @(@('Resultado','^Rechazo$'), @('MotivoError','^91$'))
}

$ok = 0; $fail = 0
foreach ($name in $checks.Keys) {
    Start-Sleep -Milliseconds ([int]($PausaSegundos * 1000))
    $file = Join-Path $dir $name
    $raw = Get-Content $file -Raw
    $action = [regex]::Match($raw, 'SOAPAction:\s*(\S+)').Groups[1].Value
    $body = [regex]::Replace($raw, '(?s)<!--.*?-->', '')
    $tmp = [IO.Path]::GetTempFileName()
    [IO.File]::WriteAllText($tmp, $body, (New-Object Text.UTF8Encoding $false))
    $resp = (& curl.exe -sk -m 60 -X POST $Url -H 'Content-Type: text/xml; charset=utf-8' -H "SOAPAction: `"$action`"" --data-binary "@$tmp") -join "`n"
    Remove-Item $tmp -ErrorAction SilentlyContinue

    $errores = @()
    try { $xml = [xml]$resp } catch { $xml = $null; $errores += 'respuesta no es XML valido' }
    if ($xml) {
        if ($resp -match '<s:Fault|<soap:Fault|<Fault') { $errores += 'SOAP Fault' }
        # Valores por nombre local de elemento (todas las apariciones)
        $vals = @{}
        foreach ($n in $xml.SelectNodes('//*')) {
            if ($n.ChildNodes.Count -eq 1 -and $n.FirstChild.NodeType -eq 'Text') {
                if (-not $vals.ContainsKey($n.LocalName)) { $vals[$n.LocalName] = @() }
                $vals[$n.LocalName] += $n.InnerText
            }
        }
        foreach ($c in $checks[$name]) {
            $campo = $c[0]; $patron = $c[1]
            if (-not $vals.ContainsKey($campo)) { $errores += "falta el campo $campo"; continue }
            if (-not ($vals[$campo] | Where-Object { $_ -match $patron })) {
                $errores += "$campo = '$($vals[$campo] -join "','")' (esperado /$patron/)"
            }
        }
        # DescripcionServicio: maximo 30 caracteres
        if ($vals.ContainsKey('DescripcionServicio')) {
            $largas = $vals['DescripcionServicio'] | Where-Object { $_.Length -gt 30 }
            if ($largas) { $errores += "DescripcionServicio supera 30 caracteres: $($largas -join ', ')" }
        }
    }
    if ($errores.Count -eq 0) { $ok++; '{0,-48} OK' -f $name }
    else { $fail++; '{0,-48} FALLA: {1}' -f $name, ($errores -join '; ') }
}
''
"Resultado: $ok correctas, $fail con falla, de $($checks.Count)."
if ($fail -gt 0) { exit 1 }


